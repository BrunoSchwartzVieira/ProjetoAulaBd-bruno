
package br.com.DAO;

import br.com.DTO.AgendaDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AgendaDAO {
     private Connection conn;

    public AgendaDAO(Connection conn) {
        this.conn = conn;
    }

    // Método para adicionar compromisso
    public boolean adicionarCompromisso(AgendaDTO agenda) {
        String sql = "INSERT INTO agenda (data, horario, descricao, id_cliente) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, agenda.getData());
            stmt.setString(2, agenda.getHorario());
            stmt.setString(3, agenda.getDescricao());
            stmt.setInt(4, agenda.getIdCliente());
            stmt.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para listar compromissos
    public List<AgendaDTO> listarCompromissos() {
        List<AgendaDTO> compromissos = new ArrayList<>();
        String sql = "SELECT * FROM agenda";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                AgendaDTO agenda = new AgendaDTO();
                agenda.setId(rs.getInt("id"));
                agenda.setData(rs.getString("data"));
                agenda.setHorario(rs.getString("horario"));
                agenda.setDescricao(rs.getString("descricao"));
                agenda.setIdCliente(rs.getInt("id_cliente"));
                compromissos.add(agenda);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return compromissos;
    }

}
